#include <stdio.h>

#define MIN(a, b) ({\
    typeof(a) _a=a;\
    typeof(b) _b=b;\
    ((_a)>(_b)?(_b):(_a));\
     })

int main(int argc, char const *argv[])
{
    printf("%d\n", MIN(8, 10));
    return 0;
}
