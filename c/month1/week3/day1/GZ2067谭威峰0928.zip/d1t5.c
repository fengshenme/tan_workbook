/*

*/
// 某头文件中有以下语句，解释其作用：
#ifndef SOME_HEADER_H_  // 如果没有定义此宏
#define SOME_HEADER_H_  // 则马上定义此宏
 //... 头文件正文
#endif // 结束