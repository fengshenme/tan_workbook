/*

1.构造一个结构体模板（图书信息），有下列成员：
序号	int
书名	char [20]
页数	int
价格	float

同时定义一个变量 stu1
可通过scanf循环输入不同的数字，执行不同的操作，如
1写入数据到该结构体变量中(可继续使用scanf输入)
2显示结构体变量所有信息

*/

#include <stdio.h>

struct d6t4
{
    int number;
    char title[20];
    int pages;
    float price;
};

int main(int argc, char const *argv[])
{
    int a;
    struct d6t4 stu1;
    while (1)
    {
        printf("录入书籍信息输入1,显示信息输入2,按0退出");
        scanf("%d", &a);
        while (getchar() != '\n')
            ;
        if (a == 1)
        {
            printf("书籍序号");
            scanf("%d", &(stu1.number));
            while (getchar() != '\n')
                ;
            printf("书名");
            scanf("%s", &(stu1.title));
            while (getchar() != '\n')
                ;
            printf("页数");
            scanf("%d", &(stu1.pages));
            while (getchar() != '\n')
                ;
            printf("价格");
            scanf("%f", &(stu1.price));
            while (getchar() != '\n')
                ;
        }

        else if (a == 2)
        {
            printf("序号\t书名\t页数\t价格\n");
            printf("%d\t%s\t%d\t%.3f\n", stu1.number, stu1.title, stu1.pages, stu1.price);
        }
        else
            break;
    }

    return 0;
}
