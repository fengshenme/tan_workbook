#include <stdio.h>
#include <stdlib.h>

typedef struct node
{
    int data;

    struct node *next;
} link_list;

//创建节点
link_list *new_node(int data);
//初始化链表
link_list *list_init(void);
// 链表打印
void list_show(link_list *pos);
// 添加到链头
int list_add(link_list *n_node, link_list *list);
// 添加到链尾
int list_tail_add(link_list *n_node, link_list *list);
// 删除节点
int del_node(int data, link_list *list);

int main(int argc, char const *argv[])
{

    int len = 9;
    int arr[] = {8, 2, 9, 4, 7, 6, 5, 3, 1};
    link_list *list = list_init();
    int i;
    for (i = 0; i < len; i++)
    {
        list_add(new_node(arr[i]), list);
    }
    list_show(list);
    link_list *lista = list_init();
    for (i = 0; i < len; i++)
    {
        list_tail_add(new_node(arr[i]), lista);
    }
    list_show(lista);
    del_node(2, lista);
    list_show(lista);

    return 0;
}

int del_node(int data, link_list *list)
{
    if (list->next == list)
    {
        printf("Empty\n");
        return 1;
    }
    link_list *pos=list, *pre;
    for(; pos->next !=list; pre = pos, pos=pos->next)
    {
        if (pos->data == data)
            break;
    }

    pre->next = pos->next;
    free(pos);
    return 0;

}

int list_tail_add(link_list *n_node, link_list *list)
{
    link_list *pos;
    for (pos = list; pos->next != list; pos = pos->next);

    n_node->next = pos->next;
    pos->next = n_node;

    return 0;
}

int list_add(link_list *n_node, link_list *list)
{

    n_node->next = list->next;
    list->next = n_node;
    return 0;
}

void list_show(link_list *list)
{
    link_list *pos;
    for (pos = list->next; pos != list; pos = pos->next)
    {
        printf("%d ", pos->data);
    }
    printf("\n");
}

link_list *new_node(int data)
{
    link_list *n_node = malloc(sizeof(link_list));
    if (n_node == NULL)
    {
        printf("malloc fialed!\n");
        return NULL;
    }
    n_node->data = data;
    n_node->next = n_node;

    return n_node;
}

link_list *list_init(void)
{
    link_list *head = malloc(sizeof(link_list));
    if (head == NULL)
    {
        printf("malloc fialed!\n");
        return NULL;
    }
    head->next = head;

    return head;
}
